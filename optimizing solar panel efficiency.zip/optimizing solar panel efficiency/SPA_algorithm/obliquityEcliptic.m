function epsilon = obliquityEcliptic(n)
    epsilon = 23.439 - 0.0000004 * n;
end