function g = meanAnomalySun(n)
    g = mod(357.528 + 0.9856003 * n, 360);
end