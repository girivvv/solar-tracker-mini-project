function setElevation(angle)
    % Implement this function to control the elevation motor
    disp(['Setting elevation to ', num2str(angle), ' degrees']);
end