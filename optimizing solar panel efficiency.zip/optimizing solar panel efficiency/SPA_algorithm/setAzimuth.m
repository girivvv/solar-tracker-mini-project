function setAzimuth(angle)
    % Implement this function to control the azimuth motor
    disp(['Setting azimuth to ', num2str(angle), ' degrees']);
end